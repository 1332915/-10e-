#!/usr/bin/env python3
import argparse, os, struct, sys
BOOT_MAGIC = b"ANDROID!"
HDR = struct.Struct("<8s10I16s512s8I")
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("img")
    ap.add_argument("-o", "--out", default="unpacked")
    a = ap.parse_args()
    d = open(a.img, "rb").read()
    if d[:8] != BOOT_MAGIC:
        print("bad magic"); sys.exit(1)
    h = HDR.unpack(d[:HDR.size])
    (magic,ksz,kaddr,rsz,raddr,ssz,saddr,taddr,psz,dtbsz,_unused,name,cmdline,r0,r1,r2,r3,r4,r5,r6,r7) = h
    def pad(x): return (x + psz - 1)//psz * psz
    off = psz
    ker = d[off:off+ksz]; off += pad(ksz)
    ram = d[off:off+rsz]; off += pad(rsz)
    sec = d[off:off+ssz]; off += pad(ssz)
    dtb = d[off:off+dtbsz] if dtbsz else b""
    os.makedirs(a.out, exist_ok=True)
    open(os.path.join(a.out,"kernel"),"wb").write(ker)
    open(os.path.join(a.out,"ramdisk"),"wb").write(ram)
    if ssz: open(os.path.join(a.out,"second"),"wb").write(sec)
    if dtbsz: open(os.path.join(a.out,"dtb"),"wb").write(dtb)
    with open(os.path.join(a.out,"header.txt"),"w") as f:
        f.write(f"kernel_size={ksz}\nkernel_addr=0x{kaddr:08x}\n")
        f.write(f"ramdisk_size={rsz}\nramdisk_addr=0x{raddr:08x}\n")
        f.write(f"second_size={ssz}\nsecond_addr=0x{saddr:08x}\n")
        f.write(f"tags_addr=0x{taddr:08x}\npage_size={psz}\ndtb_size={dtbsz}\n")
        f.write(f"name={name.rstrip(b'\\x00').decode(errors='ignore')}\n")
        f.write(f"cmdline={cmdline.rstrip(b'\\x00').decode(errors='ignore')}\n")
    print(f"Unpacked: kernel {ksz}, ramdisk {rsz}, dtb {dtbsz}, pagesize {psz}")
    print(f"kernel@0x{kaddr:08x}, ramdisk@0x{raddr:08x}, tags@0x{taddr:08x}")
    print(f"name: {name.rstrip(b'\\x00').decode()}")
    print(f"cmdline: {cmdline.rstrip(b'\\x00').decode()}")
if __name__ == "__main__":
    main()
